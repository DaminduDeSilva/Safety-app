import 'package:flutter/foundation.dart';
import 'package:flutter_sms/flutter_sms.dart' as sms;
import 'package:permission_handler/permission_handler.dart';

/// Service for sending SMS messages automatically without user interaction
class SMSService {
  /// Check if SMS permissions are granted
  static Future<bool> hasPermissions() async {
    try {
      final smsPermission = await Permission.sms.status;
      return smsPermission.isGranted;
    } catch (e) {
      debugPrint('Error checking SMS permissions: $e');
      return false;
    }
  }

  /// Request SMS permissions
  static Future<bool> requestPermissions() async {
    try {
      final smsPermission = await Permission.sms.request();
      return smsPermission.isGranted;
    } catch (e) {
      debugPrint('Error requesting SMS permissions: $e');
      return false;
    }
  }

  /// Send SMS automatically without user interaction
  static Future<bool> sendSMS({
    required String phoneNumber,
    required String message,
  }) async {
    try {
      // Check permissions first
      if (!await hasPermissions()) {
        final granted = await requestPermissions();
        if (!granted) {
          debugPrint('SMS permissions not granted');
          return false;
        }
      }

      // Send SMS using flutter_sms plugin with direct send
      final result = await sms.sendSMS(
        message: message,
        recipients: [phoneNumber],
        sendDirect: true, // This sends without opening SMS app
      );

      if (result == 'sent') {
        debugPrint('SMS sent successfully to $phoneNumber');
        return true;
      } else {
        debugPrint('SMS failed to send to $phoneNumber: $result');
        return false;
      }
    } catch (e) {
      debugPrint('Failed to send SMS to $phoneNumber: $e');
      return false;
    }
  }

  /// Send SMS to multiple contacts
  static Future<Map<String, bool>> sendBulkSMS({
    required List<String> phoneNumbers,
    required String message,
  }) async {
    final results = <String, bool>{};

    // Check permissions first
    if (!await hasPermissions()) {
      final granted = await requestPermissions();
      if (!granted) {
        debugPrint('SMS permissions not granted for bulk SMS');
        for (final phoneNumber in phoneNumbers) {
          results[phoneNumber] = false;
        }
        return results;
      }
    }

    try {
      // Send to all recipients at once
      final result = await sms.sendSMS(
        message: message,
        recipients: phoneNumbers,
        sendDirect: true,
      );

      // Mark all as successful if sent
      for (final phoneNumber in phoneNumbers) {
        results[phoneNumber] = result == 'sent';
      }
    } catch (e) {
      debugPrint('Failed to send bulk SMS: $e');
      // Send individually if bulk fails
      for (final phoneNumber in phoneNumbers) {
        final success = await sendSMS(
          phoneNumber: phoneNumber,
          message: message,
        );
        results[phoneNumber] = success;
      }
    }

    return results;
  }

  /// Alternative method using direct SMS sending with better error handling
  static Future<bool> sendDirectSMS({
    required String phoneNumber,
    required String message,
  }) async {
    try {
      // Check permissions
      if (!await hasPermissions()) {
        final granted = await requestPermissions();
        if (!granted) return false;
      }

      // Clean phone number (remove spaces, dashes, parentheses)
      final cleanedPhone = phoneNumber.replaceAll(RegExp(r'[^\d+]'), '');

      if (cleanedPhone.isEmpty) {
        debugPrint('Invalid phone number: $phoneNumber');
        return false;
      }

      // Use flutter_sms direct send
      final result = await sms.sendSMS(
        message: message,
        recipients: [cleanedPhone],
        sendDirect: true,
      );

      final success = result == 'sent';
      debugPrint('Direct SMS send result: $result, Success: $success');
      return success;
    } catch (e) {
      debugPrint('Direct SMS send failed: $e');
      return false;
    }
  }

  /// Send SMS with enhanced error handling and retries
  static Future<bool> sendSMSWithRetry({
    required String phoneNumber,
    required String message,
    int maxRetries = 2,
  }) async {
    for (int attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        final success = await sendDirectSMS(
          phoneNumber: phoneNumber,
          message: message,
        );

        if (success) {
          return true;
        }

        if (attempt < maxRetries) {
          debugPrint('SMS send attempt ${attempt + 1} failed, retrying...');
          await Future.delayed(Duration(milliseconds: 500 * (attempt + 1)));
        }
      } catch (e) {
        debugPrint('SMS send attempt ${attempt + 1} error: $e');
        if (attempt == maxRetries) {
          return false;
        }
      }
    }

    return false;
  }
}
